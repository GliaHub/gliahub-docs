# Gliahub RFC Pack

This document seeds the first architectural RFCs. Each RFC should eventually become its own file in `gliahub-rfcs`.

## RFC-0001 — Organization, Workspace, and Project Model

### Problem
Gliahub must support individual users, academic labs, core facilities, and later enterprise/institutional deployments without changing the data model.

### Decision
Use a hierarchy:

```text
User
  -> Organization
      -> Workspace
          -> Project
```

A personal user is modeled as a one-person organization.

### Consequences
All datasets, workflows, runs, artifacts, reports, plugins, and permissions must be scoped to at least a workspace/project.

---

## RFC-0002 — Dataset Snapshot Model

### Problem
Large neuroscience data cannot be versioned like source code.

### Decision
Store raw and derived data in object storage and version immutable dataset manifests.

A dataset snapshot contains snapshot ID, parent snapshot ID, object paths, checksums, file sizes, BIDS/NWB metadata, modality, created by, and created at.

### Consequences
Git is not the primary data versioning system. Dataset versioning is manifest-based.

---

## RFC-0003 — Workflow Specification

### Problem
Visual workflows must be reproducible, exportable, and executable.

### Decision
Use JSON as canonical workflow format.

A workflow version contains graph nodes, graph edges, node parameter values, plugin package/version references, runtime/image digests, input/output port contracts, and resource hints.

### Consequences
React Flow state is not the whole workflow. The workflow spec is the product contract.

---

## RFC-0004 — Product-Native Versioning

### Problem
Researchers need reproducible history without Git complexity.

### Decision
Use Kaggle-like native versions:

```text
workflow draft = mutable
workflow version = immutable
dataset snapshot = immutable
execution run = immutable
```

### Alternatives considered
- Raw Git wrapping
- Git LFS
- Datalad-only model
- Custom manifest snapshots

### Consequences
Users get save version, diff, restore, fork, run history. Git remains useful for export and plugin development.

---

## RFC-0005 — Execution Backend and Runner Security

### Problem
Scientific code must run in isolated environments without locking the platform into Kubernetes on day one.

### Decision
Start with Docker SDK runner behind an `ExecutionBackend` interface.

```go
type ExecutionBackend interface {
    StartRun(ctx context.Context, spec RunSpec) (RunHandle, error)
    CancelRun(ctx context.Context, runID string) error
    GetStatus(ctx context.Context, runID string) (RunStatus, error)
    StreamLogs(ctx context.Context, runID string) (<-chan LogLine, error)
}
```

### Security evolution
- MVP: Docker SDK with strict flags.
- Pilot: isolated runner VM/host.
- Core/hosted: containerd, gVisor, Firecracker evaluation.
- Enterprise: K8s Jobs/Argo adapter.

### Consequences
Kubernetes/Argo is a future backend, not MVP dependency.

---

## RFC-0006 — Plugin Manifest Format

### Problem
Gliahub needs a stable way to describe domain-specific nodes, parameters, runtime requirements, and marketplace entitlements.

### Decision
Use JSON plugin manifests validated with JSON Schema.

A plugin manifest includes package name, version, domain, runtime image digest, nodes, input/output ports, parameter schemas, resource hints, permissions/capabilities, license, and trust status.

### Consequences
Plugin authors may use a Python SDK/decorator layer to generate manifests, but JSON is the canonical runtime contract.

---

## RFC-0007 — Provenance Model

### Problem
Users must be able to answer: “Where did this figure/report/artifact come from?”

### Decision
Represent provenance as append-only events and graph edges.

Core event types:

- `workflow_version_created`
- `dataset_snapshot_created`
- `run_started`
- `workflow_version_used`
- `dataset_snapshot_used`
- `node_started`
- `node_completed`
- `artifact_produced`
- `report_generated`
- `run_completed`
- `run_failed`

### Consequences
Graph database is not required at first. PostgreSQL tables are sufficient.

---

## RFC-0008 — Open-Source Boundary

### Problem
Academic adoption requires trust and anti-lock-in.

### Decision
Open source: specs, SDKs, CLI, local runner, basic official nodes, export tools.

Commercial/source-available: hosted control plane, marketplace backend, billing, enterprise admin, advanced audit/compliance.

### Consequences
The product can monetize hosted collaboration and governance without trapping researchers.
